package DENIS;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class REMOVE extends JFrame {

	private JPanel contentPane;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					REMOVE frame = new REMOVE();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public REMOVE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JLabel lblNewLabel_1 = new JLabel("BOOKCODE");
		contentPane.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("REMOVE");
		contentPane.add(btnNewButton);
		JButton btnNewButton_1 = new JButton("REMOVED BOOKS");
		contentPane.add(btnNewButton_1);
		 btnNewButton.addActionListener(new ActionListener() {
			   public void actionPerformed(ActionEvent e) {
			
				   if(e.getSource()==btnNewButton) {
					 
					   JOptionPane.showMessageDialog( btnNewButton,"NEW BOOK IS REMOVED");
				   }}});
		 
		 btnNewButton_1.addActionListener(new ActionListener() {
			   public void actionPerformed(ActionEvent e) {
			
				   if(e.getSource()==btnNewButton_1) {
					 
				
				   }}});
	}

}
