package DENIS;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class ADDEDBOOKS extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	// Database connection details
	private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/denis";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	EventQueue.invokeLater(new Runnable() {
	public void run() {
	try {
	ADDEDBOOKS frame = new ADDEDBOOKS();
	frame.setVisible(true);
	frame.setTitle("ADDED NEW BOOKS");
	} catch (Exception e) {
	e.printStackTrace();
    }
	}
	});
	}

	/**
	 * Create the frame.
	 */
	public ADDEDBOOKS() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("BOOK NAME");
		lblNewLabel.setBounds(10, 11, 89, 14);
		contentPane.add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(109, 8, 315, 20);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("BOOKCODE");
		lblNewLabel_1.setBounds(10, 36, 89, 14);
		contentPane.add(lblNewLabel_1);

		textField_1 = new JTextField();
		textField_1.setBounds(109, 33, 315, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("BOOK AUTHORS");
		lblNewLabel_2.setBounds(10, 61, 89, 14);
		contentPane.add(lblNewLabel_2);

		textField_2 = new JTextField();
		textField_2.setBounds(109, 58, 315, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("BOOK LOCATION");
		lblNewLabel_3.setBounds(10, 86, 89, 14);
		contentPane.add(lblNewLabel_3);

		textField_3 = new JTextField();
		textField_3.setBounds(109, 83, 315, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);

		JButton btnNewButton = new JButton("ADD");
		btnNewButton.setBounds(10, 141, 89, 23);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("CHECK ADDED BOOKS");
		btnNewButton_1.setBounds(109, 141, 176, 23);
		contentPane.add(btnNewButton_1);

		JButton btnNewButtonR = new JButton("REMOVE BOOKS");
		btnNewButtonR.setBounds(295, 141, 129, 23);
		contentPane.add(btnNewButtonR);

		btnNewButton.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNewButton) {
		String bookName = textField.getText();
		String bookCode = textField_1.getText();
		String bookAuthor = textField_2.getText();
		String bookLocation = textField_3.getText();

					// Add book to database
boolean success = addBookToDatabase(bookName, bookCode, bookAuthor, bookLocation);

		if (success) {
		JOptionPane.showMessageDialog(btnNewButton, "New book is added");
						// Clear input fields
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		} else {
		JOptionPane.showMessageDialog(btnNewButton, "Failed to add the book");
		}
		}
		}
		});

btnNewButton_1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNewButton_1) {
		// Code for checking added books
		}
		}
		});

		btnNewButtonR.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNewButtonR) {
		REMOVE R = new REMOVE();
		R.setVisible(true);
		}
		}
		});
	    }

	private boolean addBookToDatabase(String bookName, String bookCode, String bookAuthor, String bookLocation) {
		try (Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD)) {
		String query = "INSERT INTO books (book_name, book_code, book_author, book_location) VALUES (?, ?, ?, ?)";
		PreparedStatement statement = connection.prepareStatement(query);
		statement.setString(1, bookName);
		statement.setString(2, bookCode);
		statement.setString(3, bookAuthor);
		statement.setString(4, bookLocation);

		int rowsInserted = statement.executeUpdate();
		return rowsInserted > 0;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return false;
	    }
        }

