package DENIS;


import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class INSATI {

 private JFrame frame;
 
 private JTextField id;
 private JTextField name;
 private JTextField sector;
 
 public static void main(String[] args) {
  EventQueue.invokeLater(new Runnable() {
   public void run() {
    try {
    	INSATI window = new INSATI();
     window.frame.setVisible(true);
    } catch (Exception e) {
     e.printStackTrace();
    }
   }
  });
 }

 public INSATI() {
  initialize();
 }

JTable table = new JTable();
 private void initialize() {
 
  frame = new JFrame();
  frame.setTitle("VIEW FORM");
  frame.setBounds(430, 200, 500, 300);
  frame.getContentPane().setBackground(Color.pink);
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  frame.getContentPane().setLayout(null);
  
  Object [] colomns={"id","name","sector"};
  DefaultTableModel model= new DefaultTableModel();
  model.setColumnIdentifiers(colomns);
  table.setModel(model);
  
  
  id = new JTextField();
  id.setBounds(10, 11, 133, 20);
  frame.getContentPane().add(id);
  id.setColumns(10);
 
  
  name = new JTextField();
  name.setBounds(10, 73, 133, 20);
  frame.getContentPane().add(name);
  name.setColumns(10);
  
  sector = new JTextField();
  sector.setBounds(10, 135, 133, 20);
  frame.getContentPane().add(sector);
  sector.setColumns(10);
  
  
  JLabel lblid = new JLabel("id");
  lblid.setBounds(151, 11, 95, 20);
  frame.getContentPane().add(lblid);
  
  JLabel lblname = new JLabel("name");
  lblname.setBounds(151, 73, 95, 20);
  frame.getContentPane().add(lblname);
  
  JLabel lblsector = new JLabel("sector");
  lblsector.setBounds(151, 135, 95, 20);
  frame.getContentPane().add(lblsector);
    
  JScrollPane scrollPane = new JScrollPane(table);
  scrollPane.setBounds(10, 160, 464, 115);
  frame.getContentPane().add(scrollPane);
  
  JButton btnInsert = new JButton("Insert");
  Object [] row = new Object[4];
  btnInsert.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
	   row[0]=id.getText();
	   row[1]=name.getText();
	   row[2]=sector.getText(); 
	   try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
		// Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("Driver loaded");
		Connection connection = null;
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost/Test DB","root","");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("Connection established");
		Statement stmt = null;
		try {
			stmt = connection.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// Execute a query
		System.out.println("Inserting records into the table...");   
		//String id=idfield.getText();
		//String name=namefield.getText();
		String sql = "INSERT INTO test1 VALUES ('"+row[0]+"','"+row[1]+"','"+row[2]+"')";
		try {
			stmt.executeUpdate(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("Inserted records into the table..."); 
    model.addRow(row);
    
   }
   });
 
  
  btnInsert.setBounds(230, 89, 89, 23);
  frame.getContentPane().add(btnInsert);
  
   }
 }
  
