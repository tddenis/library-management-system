package DENIS;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class BORROWERLOGIN extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BORROWERLOGIN frame = new BORROWERLOGIN();
					frame.setTitle("BROWER FORM");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BORROWERLOGIN() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("USERNAME");
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		contentPane.add(textField);
		textField.setColumns(10);
	
		JLabel lblNewLabel_1 = new JLabel("PASSWORD");
		contentPane.add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		contentPane.add(passwordField);
		passwordField.setColumns(10);
		JButton btnNewButton_1 = new JButton("LOGIN");
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(this);
		JButton	S = new JButton("SIGN UP");
		contentPane.add(S);
		 
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		

			   try {
				   
			         Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/denis", "root", "");
                    
			         Statement stmt = con.createStatement();
			         String query = "select UserName,Password from borrower";
			         ResultSet rs=stmt.executeQuery(query);
			         if((textField.getText()).equals("") && (passwordField.getText()).equals(""))
			         {
			        	 JOptionPane.showMessageDialog(null,"please fill all the fields", "",  JOptionPane.WARNING_MESSAGE );
			         }
			         else {
			         while(rs.next()) {
			             String usname = rs.getString("UserName");
			             String pass = rs.getString("Password");
			             if((textField.getText()).equals(usname) && (passwordField.getText()).equals(pass))
			             {
			            	 JOptionPane.showMessageDialog(null,"Login successfully..................", "",  JOptionPane.WARNING_MESSAGE );
			            	P1 p1= new P1();
			            	 p1.setVisible(true);
			            	 
			             }
			             
			            
			
			              }
			         
			         }}
			   
			   catch (SQLException se) {
	           se.printStackTrace();
	        
		
	}}}
			
	
		


    
