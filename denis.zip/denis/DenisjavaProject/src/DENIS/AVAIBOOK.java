package DENIS;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;

public class AVAIBOOK extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AVAIBOOK frame = new AVAIBOOK();
					frame.setVisible(true);
					frame.setTitle("CHECK AVAILABLE  BOOKS");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AVAIBOOK() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JButton btnNewButton_2 = new JButton("BOOK1");
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("BOOK2");
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("OTHER BOOKS");
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton = new JButton("AVAILABLE BOOKS");
		contentPane.add(btnNewButton);
		

	}

}
