package DENIS;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class ADMINLOGIN extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ADMINLOGIN frame = new ADMINLOGIN();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ADMINLOGIN() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("USERNAME");
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD");
		contentPane.add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		contentPane.add(passwordField);
		passwordField.setColumns(10);
		JButton btnNewButton = new JButton("LOGIN");
		contentPane.add(btnNewButton);
		
		 
		 btnNewButton.addActionListener(new ActionListener() {
			   public void actionPerformed(ActionEvent e) {
				   String u=passwordField.getText();
				   String p=textField.getText();
				   if(u.equals("12345")&&p.equals("deni")) {
					   JOptionPane.showMessageDialog( btnNewButton,"LOGIN SUCCESSFULLY");
					   NEWBOOK fe=new    NEWBOOK();
					   fe.setVisible(true);}
					   else {
						   JOptionPane.showMessageDialog( btnNewButton,"INCORRECT PASSWORD");
				   }}});
	}

}
