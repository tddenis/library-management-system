package DENIS;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class REMORE implements ActionListener {
	// Labels
	JFrame fr = new JFrame();
	JLabel user = new JLabel("UserName:");
	JLabel pass = new JLabel("Password:");
	JLabel name = new JLabel("Full Name:");
	JLabel address = new JLabel("ADDRESS");
	JLabel contact = new JLabel("CONTACT");
	JLabel gender1 = new JLabel("GENDER");
	String[] gender = { "Male", "Female" };

	JComboBox<String> icombo1 = new JComboBox<>(gender);
	JTextField userf = new JTextField();
	JPasswordField passf= new JPasswordField();
	JTextField namef = new JTextField();
	JTextField nidf = new JTextField();
	JTextField addressf = new JTextField();
	JTextField contactf = new JTextField();
	JButton create = new JButton("Register");
	JButton back = new JButton("Reset");

	public REMORE() {
		
		a();
	}

	private void a() {
		create.addActionListener(this);
		back.addActionListener(this);
		fr.add(user);
		fr.add(pass);
		fr.add(name);
		fr.add(contact);
		fr.add(address);
		fr.add(userf);
		fr.add(passf);
		fr.add(create);
		fr.add(back);

		fr.add(contactf);
		fr.add(addressf);
		fr.add(nidf);
		fr.add(namef);
		fr.add(create);
		fr.add(back);
		fr.add(icombo1);
		user.setBounds(30, 30, 150, 30);
		pass.setBounds(30, 100, 150, 30);
		name.setBounds(30, 170, 100, 30);

		address.setBounds(30, 240, 150, 30);
		gender1.setBounds(30, 380, 150, 30);
		contact.setBounds(30, 310, 150, 30);
		userf.setBounds(150, 30, 150, 30);
		passf.setBounds(150, 100, 150, 30);
		namef.setBounds(150, 170, 150, 30);
		nidf.setBounds(150, 240, 150, 30);
		addressf.setBounds(150, 310, 150, 30);
		icombo1.setBounds(150, 380, 150, 30);
		contactf.setBounds(150, 170, 150, 30);
		create.setBounds(150, 450, 100, 30);

		back.setBounds(180, 240, 100, 30);
        fr.add(gender1);
		fr.setTitle("");
		fr.setBounds(300, 50, 400, 550);
		fr.getContentPane().setLayout(null);
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fr.setResizable(true);

	}

	public static void main(String[] args) {
		new REMORE();
	}

	@Override
	public void actionPerformed(ActionEvent i) {
		


		if (i.getSource() == create) {
			System.out.println("Connection established succesfully");
			JOptionPane.showMessageDialog(null, "Connection established succesfully", "",
					JOptionPane.INFORMATION_MESSAGE);
			String db = "jdbc:mysql://localhost:3306/denis";
			String un = "root";
			String pass = "";

			try {
				Connection con = DriverManager.getConnection(db, un, pass);
				if (con != null) {
					System.out.println("Connection established succesfully");
					JOptionPane.showMessageDialog(null, "Connection established succesfully", "",
							JOptionPane.INFORMATION_MESSAGE);
					String sql = "INSERT INTO borrower(UserName,Password,FullName,Address,Contact,Gender) VALUES (?,?,?,?,?,?)";
					PreparedStatement st1 = con.prepareStatement(sql);
				 
					st1.setString(1,userf.getText());
					st1.setString(2, passf.getText());
					st1.setString(3, namef.getText());
					st1.setString(4,addressf.getText());
					st1.setString(5, contactf.getText());
					st1.setString(6, (String) icombo1.getSelectedItem());

					int rows = st1.executeUpdate();
					if (rows > 0) {
						System.out.println("Created succesfully");
						JOptionPane.showMessageDialog(null, "Created succesfully", "",
								JOptionPane.INFORMATION_MESSAGE);
					}

					else {
						System.out.println(" not created");
						JOptionPane.showMessageDialog(null, "Connection not established succesfully", "",
								JOptionPane.INFORMATION_MESSAGE);
					}

				}
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			userf.setText("");
			passf.setText("");
			namef.setText("");
			nidf.setText("");
		addressf.setText("");
			contactf.setText("");
		}

	}

}

// }

