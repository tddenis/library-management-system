-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 09. Jun 2023 um 19:52
-- Server-Version: 10.4.25-MariaDB
-- PHP-Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `denis`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `book_name` varchar(255) DEFAULT NULL,
  `book_code` varchar(255) DEFAULT NULL,
  `book_author` varchar(255) DEFAULT NULL,
  `book_location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `books`
--

INSERT INTO `books` (`id`, `book_name`, `book_code`, `book_author`, `book_location`) VALUES
(1, 'Harrz poter', '555', 'denis ttt', 'tttt'),
(2, 'mwami', '2324', 'clema', 'hih zone'),
(3, 'zurrrttr', '564', 'denis', 'jdkk'),
(4, 'gjjjx', 'uhuh', 'uiuiiu', 'uiu'),
(5, 'DTER', 'ASRE4T', 'TRD', 'RGTER'),
(6, 'av', '12b', 'td', 'musannze'),
(7, 'tobi', '23p', 'demo', 'vilo'),
(8, 'tzrgkrgo', 'ifgkfg', 'urgir', 'ifgjk');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `borrower`
--

CREATE TABLE `borrower` (
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Contact` varchar(100) NOT NULL,
  `Gender` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `borrower`
--

INSERT INTO `borrower` (`UserName`, `Password`, `FullName`, `Address`, `Contact`, `Gender`) VALUES
('', '', '', '', '', 'Male'),
('Denis', '123', '', 'kkkkkk', 'ggg', 'Male'),
('hhhhhhhhhh', 'kkkkkkkkkk', '', '777777777', 'lllllllll', 'Female'),
('mwiza', '123', '', '0789999900', 'mwiza diane', 'Female'),
('mwiza', '0000', '', '0788888834', 'mwiza denis', 'Female');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
